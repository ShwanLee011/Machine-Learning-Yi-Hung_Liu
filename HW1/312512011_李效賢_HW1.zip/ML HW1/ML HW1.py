import itertools
import numpy as np
import matplotlib.pyplot as plt

# test data
irisA = []
irisB = []
irisC = []

# Read input file
def readfile():
    data = []
    labels = []
    lines = open("d:\iris.txt")
    for line in lines:
        parts = line.split()
        row = [float(x) for x in parts[:-1]] 
        label = int(parts[-1]) 
        data.append(row)
        labels.append(label)
    data = np.array(data)
    labels = np.array(labels)
    with open('d:\iris.txt') as f:
        for line in f:
            line = line.strip().replace('  ', ' ').split(' ')
            iris_type = line[-1]
            iris_data = [ float(num) for num in line[:-1] ] + [ line[-1] ]
            if iris_type == '1':
                irisA.append(iris_data)
            elif iris_type == '2':
                irisB.append(iris_data)
            elif iris_type == '3':
                irisC.append(iris_data)
        
    feature_names = ['Sepal Length', 'Sepal Width', "Petal Length", "Petal Width"]

    # Generate all the combinations C(4,2)=6 plots
    feature_indices = range(4)
    combinations = list(itertools.combinations(feature_indices, 2))

    # Generate a list of colors for each label
    label_colors = {0: 'red', 1: 'green', 2: 'blue'}

    # Generate plots
    for feature1_idx, feature2_idx in combinations:
        feature1_values = [point[feature1_idx] for point in data]
        feature2_values = [point[feature2_idx] for point in data]
        labels = [int(point[-1]) for point in data] 

        plt.figure()
        point_colors = [label_colors[label] for label in labels]

        plt.scatter(feature1_values, feature2_values, c=point_colors)
        plt.xlabel(feature_names[feature1_idx])
        plt.ylabel(feature_names[feature2_idx])
        plt.title(f'Feature Combination: ({feature_names[feature1_idx]}, {feature_names[feature2_idx]})')
    
    plt.show()
    
# For sorting
def sortfunc(e):
    return e[0]

# Will return correct rate
def KNN(train, test, features, K):
    wrong = 0
    correct = 0
    total = 0
    for t in test:
        # Calculate distance
        dist = []
        # Training data
        for tr in train:
            d = 0
            for f in features:
                d += (tr[f] - t[f]) ** 2
            # Save distance & type
            dist.append((d, tr[-1]))
        dist.sort(key=sortfunc)
        neighbor = {'1': 0, '2': 0, '3': 0}
        for i in range(0, K):
            neighbor[dist[i][1]] += 1

        max_value = max(neighbor, key=neighbor.get)
        if max_value == t[-1]:
            correct += 1
        else:
            wrong += 1
        total += 1
    return float(correct) / float(total)

def main():
    kvalue = [1, 3]
    readfile()
    set1 = irisA[:25] + irisB[:25] + irisC[:25]
    set2 = irisA[25:] + irisB[25:] + irisC[25:]
    features = [0, 1, 2, 3]
    for k in kvalue:
        print("knn k=" + str(k))
        for i in range(1, 5):
            feats = itertools.combinations(features, i)
            for feat in feats:
                print(feat)
                print("%.2f%%" % (100 * (KNN(set1, set2, feat, k) + KNN(set2, set1, feat, k)) / 2.0))

if __name__ == "__main__":
    main()
